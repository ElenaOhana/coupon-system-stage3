package com.couponsystemstage3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
//@EnableScheduling
public class CouponSystemStage3Application {

	public static void main(String[] args) {
		SpringApplication.run(CouponSystemStage3Application.class, args);
	}
}
