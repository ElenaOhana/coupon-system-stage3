package com.couponsystemstage3.types;

public enum ClientStatus {
    ACTIVE, INACTIVE
}
