package com.couponsystemstage3.types;

public enum CouponStatus {
    ABLE, DISABLE
}
