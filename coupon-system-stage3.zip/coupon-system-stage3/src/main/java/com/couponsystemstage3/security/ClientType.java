package com.couponsystemstage3.security;

public enum ClientType {
    ADMINISTRATOR, COMPANY,CUSTOMER
}
