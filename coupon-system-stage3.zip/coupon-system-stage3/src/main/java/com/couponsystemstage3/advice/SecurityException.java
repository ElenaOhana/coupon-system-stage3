package com.couponsystemstage3.advice;

public class SecurityException extends Exception{

    public SecurityException(String msg) {
        super(msg);
    }
}
