package com.couponsystemstage3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouponSystemStage3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
